import java.sql.*;

/**
 * Classe que faz a Conexao via JDBC com pacote
 * mysql-connect 8.0.30
 *
 */
public class Conexao {

    /** objeto Connection
    * */
    private Connection conexao;
    /** Construtor do objeto Conexao que faz a
     * ligação com o Banco de Dados
    * */
    public Conexao()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexao =
                    DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/comabem",
                            "root",
                            "12345678");

        }catch (Exception e)
        {
            System.out.println("Erro na Conexão:"+e);
        }
    }

    /**
     *  Método que retorna a Conexao criada
     */

    public Connection getConexao()
    {
        return this.conexao;
    }



}
