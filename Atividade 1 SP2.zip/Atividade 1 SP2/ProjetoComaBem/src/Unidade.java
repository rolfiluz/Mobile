public class Unidade {

    private int uni_cod;
    private String uni_medida;

    public int getUni_cod()
    {
        return this.uni_cod;
    }
    public void setUni_cod(int aux)
    {
        this.uni_cod = aux;
    }
    //     private String uni_medida;
    public String getUni_medida()
    {
        return this.uni_medida;
    }

    public void setUni_medida(String aux){
        this.uni_medida = aux;
    }
}
