public class Main {
    //Codifique as classes de objeto para a aplicação de compras dos produtos,
    // com uma classe para cada tabela, utilizando a ferramenta idea InteliJ.
    public static void main(String[] args) {

        Produtos p1= new Produtos();
        Unidade u1= new Unidade();

        p1.setProd_cod(2);
        p1.setProd_nome("Carne");
        p1.setProd_quantidade(2.00);
        p1.setProd_valor(30.00);
        p1.setUni_cod(1);

        u1.setUni_cod(1);
        u1.setUni_medida("kilo");

        System.out.println("O produto cadastrado é:");
        System.out.println("O código é:" + p1.getProd_cod());
        System.out.println("O nome é:"+ p1.getProd_nome());
        System.out.println("A quantidade é:"+ p1.getProd_quantidade());
        System.out.println("O valor é:" + p1.getProd_valor());
        System.out.print("A unidade de medida é:" + p1.getUni_cod());

    }
}